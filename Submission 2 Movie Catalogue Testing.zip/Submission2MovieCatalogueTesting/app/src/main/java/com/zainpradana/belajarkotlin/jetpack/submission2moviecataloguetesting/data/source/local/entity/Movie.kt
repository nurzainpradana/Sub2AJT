package com.zainpradana.belajarkotlin.jetpack.submission2moviecataloguetesting.data.source.local.entity

data class Movie(
        var movieId: Int,
        var moviePoster: Int,
        var movieTitle: String,
        var movieGenre: String,
        var movieDescription: String,
        var movieYear: String)