package com.zainpradana.belajarkotlin.jetpack.submission2moviecataloguetesting.data.source.local.entity

data class TvShow(
        var tvShowId: Int,
        var tvShowPoster: Int,
        var tvShowTitle: String,
        var tvShowGenre: String,
        var tvShowDescription: String,
        var tvShowYear: String)